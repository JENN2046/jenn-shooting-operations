# G3-03 independent patch review — initial

Verdict: PASS_INITIAL_SOURCE_AND_LOCAL_REGRESSION. Final exact-head / isolated integration signoff remains pending.

Reviewer: independent Verifier sub-agent, not an author of implementation or submitted tests. Read-only implementation review; ran local disposable synthetic tests. No production access or mutation. Reviewed revised-task.md and frozen method-freeze.md.

Base: 620136f322fddd194144ae90a44d833a40e15fff.
Reviewed worktree witness SHA256: f12b9ec94323b11eaafdc5c41ceb1fb4628afc3311ed307eec8272f6c4fcb7ea.
Reviewed new test SHA256: d71996d59427feee13acd3523d84e026f68d046b66feba4e6672abf155333a3b.

No actionable defect found in the bounded patch:

- Raw snapshot accepts only matched 1/1 or 2/2. SHA256 and returned header remain raw. Only the immutable Python bytes copy supplied to in-memory deserialize is normalized 2/2 → 1/1; original file has no write handle.
- All three sidecar names are checked relative to the traversed final directory, both before read and after analysis. lstat semantics catch dangling symlinks. Permission/other lookup failures propagate rather than masquerading as absence.
- O_NOATIME is mandatory, no ordinary-read retry exists. Both sampled reads use the opened descriptor. Full metadata comparison includes atime. The unavailable/permission-denied unit tests are explicitly controlled failures, not real kernel authorization tests; guest evidence remains necessary for integrated claims.
- Parent traversal begins at / with no-follow directory descriptors. Leaf open is relative to the final parent FD; initial parent pin, open-time rewalk and final rewalk agree, and final pathname inode matches actual FD. Full ancestor identity/owner/group/mode checked. Parent replacements preserving child/leaf inode are covered. These bounded checks do not claim protection against a malicious trusted administrator or uninterrupted race-free custody.
- `prove`, typed value framing, multiset rowset digest, rowid handling and main are AST-identical to baseline. Existing semantic checks, exact G3 source digests, migration identities, metadata exclusions and authority-denying artifact fields were not relaxed. G2/G3 gate/state-machine source files are absent from diff.
- Optional signed-envelope verifier remains unchanged and cannot be claimed 2/2 compatible; DEFER must remain explicit in delivery.

Independently executed command:
`python3 -m unittest discover -s tests -p 'test_g3*witness*.py' -v`
Result: 24/24 PASS (12 inherited regression + 12 new compatibility test methods), 0.075 seconds. Subtests are not separately counted. Python 3.14.4, SQLite 3.46.1. Synthetic fixtures only, local temporary directories cleaned by tests. Assertions reviewed against implementation; PASS values are computed, not prefilled evidence. New tests cover checkpointed real SQLite WAL headers, raw hash/metadata preservation, mixed/unknown formats, sidecars/dangling links, NOATIME rejection, parent/leaf drift, atime drift and semantic negative under WAL.

Remaining review inputs: final commit ID and diff, exact guest code/runtime pins, real isolated E1/E2/E3 integration outputs and custody receipts, evidence manifest and inherited/new coverage matrix. This initial review does not grant final PASS_ISOLATED_G3_03 or production admission.
