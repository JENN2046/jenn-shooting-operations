import sys,os,json,subprocess,pathlib,sqlite3,importlib.util
sys.path.insert(0,'/opt/jso')
import e1_guest as e
spec=importlib.util.spec_from_file_location('w','/opt/jso/witness.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
expected=json.loads(e.STATE.read_text());out=[]
def record(name,ok,**kw):
    out.append(dict(case=name,pass_=bool(ok),**kw));assert ok,name
# Actual kernel NOATIME denial on root-owned originals with an unprivileged uid.
code="import sys,os;sys.path.insert(0,'/opt/jso');import witness;witness.capture('/var/lib/jso-fixture/originals/preserved.sqlite','/var/lib/jso-fixture/originals/active.sqlite','synthetic')"
r=subprocess.run(['setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-c',code],capture_output=True,text=True)
record('real_noatime_permission_denied',r.returncode!=0 and 'PermissionError' in r.stderr,exit=r.returncode,stderr=r.stderr)
# Real ordinary writer cannot modify the newly used witness originals.
r=subprocess.run(['setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-c',"import os;os.open('/var/lib/jso-fixture/originals/active.sqlite',os.O_WRONLY)"],capture_output=True,text=True)
record('ordinary_writer_denied_on_integrated_original',r.returncode!=0 and 'PermissionError' in r.stderr,exit=r.returncode)
# A private mount namespace aliases the SAME inodes; it does not create different data.
script="""import sys,os,pathlib,subprocess,json
sys.path.insert(0,'/opt/jso');import witness
alias=pathlib.Path('/var/lib/jso-fixture/mount-alias');alias.mkdir(exist_ok=True)
subprocess.run(['mount','--bind','/var/lib/jso-fixture/originals',str(alias)],check=True)
try:
 r=witness.capture(str(alias/'preserved.sqlite'),str(alias/'active.sqlite'),'synthetic')
 print(json.dumps(dict(ns=os.readlink('/proc/self/ns/mnt'),identities=r['fileIdentities'],status=r['status'])))
finally:subprocess.run(['umount',str(alias)],check=True);alias.rmdir()
"""
r=subprocess.run(['unshare','--mount','--propagation','private','python3','-c',script],capture_output=True,text=True,check=True);alias=json.loads(r.stdout)
record('real_private_mount_alias_same_original_inodes',alias['ns']!=os.readlink('/proc/self/ns/mnt') and all(alias['identities'][side]['inode']==x['ino'] and alias['identities'][side]['device']==x['dev'] for side,x in zip(['active','prestate'],expected['files'])),alias=alias,controller_namespace=os.readlink('/proc/self/ns/mnt'))
record('custody_still_protected',e.protection_state(expected)=='PROTECTED')
print(json.dumps({'results':out,'count':len(out),'pass':True}))
