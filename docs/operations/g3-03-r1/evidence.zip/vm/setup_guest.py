import json,os,sqlite3,subprocess,sys
sys.path.insert(0,'/opt/jso')
from fixture import fixture
import e1_guest as e
assert not e.ROOT.exists()
e.DATA.mkdir(parents=True,mode=0o755)
for p in e.FILES:
    fixture(p,additional=(p==e.FILES[0]))
    db=sqlite3.connect(p);assert db.execute('PRAGMA journal_mode=WAL').fetchone()[0]=='wal';db.execute('PRAGMA wal_checkpoint(TRUNCATE)');db.close()
    os.chmod(p,0o666);os.utime(p,ns=(1000000000,2000000000))
    subprocess.run(['chattr','+i',str(p)],check=True)
facts={'files':[e.ident(p) for p in e.FILES],'parent_chain':e.pin_parent_chain(),'fs':subprocess.check_output(['findmnt','-n','-o','FSTYPE','-T',str(e.DATA)]).decode().strip()}
assert facts['fs']=='ext4'
e.STATE.write_text(json.dumps(facts,indent=2));os.sync()
assert e.protection_state(facts)=='PROTECTED'
print(json.dumps(facts))
