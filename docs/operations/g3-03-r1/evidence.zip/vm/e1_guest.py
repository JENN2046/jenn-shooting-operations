import os, sys, pathlib, json, subprocess, hashlib, fcntl, array, errno, sqlite3, signal, time, stat, contextlib
ROOT=pathlib.Path('/var/lib/jso-fixture')
DATA=ROOT/'originals'
FILES=[DATA/'active.sqlite',DATA/'preserved.sqlite']
STATE=ROOT/'state.json'
RESULT=[]
GET=0x80086601
def flags(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        a=array.array('L',[0]);fcntl.ioctl(fd,GET,a,True);return a[0]
    finally:os.close(fd)
def ident(p):
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        s=os.fstat(fd);h=hashlib.sha256()
        while b:=os.read(fd,65536):h.update(b)
        return dict(dev=s.st_dev,ino=s.st_ino,size=s.st_size,nlink=s.st_nlink,sha256=h.hexdigest(),flags=flags(p))
    finally:os.close(fd)
def event(name,ok,**detail):
    row=dict(case=name,pass_=bool(ok),detail=detail);RESULT.append(row)
    if not ok: raise AssertionError(json.dumps(row))
def chattr(p,on=True):return subprocess.run(['chattr','+i' if on else '-i',str(p)],capture_output=True,text=True)
def check_same(p,expected):
    a=ident(p);return all(a[k]==expected[k] for k in ['dev','ino','size','sha256','nlink'])
@contextlib.contextmanager
def parent_chain():
    # Open every directory relative to the already-pinned ancestor, never follow links.
    fds=[];pins=[]
    try:
        for index,name in enumerate(DATA.parts):
            fd=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fds[-1] if fds else None)
            fds.append(fd);s=os.fstat(fd)
            pins.append(dict(component=name,dev=s.st_dev,ino=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode)))
        yield pins,fds[-1]
    finally:
        for fd in reversed(fds):os.close(fd)
def pin_parent_chain():
    with parent_chain() as (pins,fd):return pins
def pinned_file_identity(directory_fd,name):
    fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=directory_fd)
    try:
        s=os.fstat(fd);a=array.array('L',[0]);fcntl.ioctl(fd,GET,a,True);h=hashlib.sha256()
        while b:=os.read(fd,65536):h.update(b)
        return dict(dev=s.st_dev,ino=s.st_ino,size=s.st_size,nlink=s.st_nlink,sha256=h.hexdigest(),flags=a[0])
    finally:os.close(fd)
def no_privileges():
    os.setgroups([]);os.setgid(65534);os.setuid(65534)
def negative(name,code,args):
    r=subprocess.run([sys.executable,'-c',code,*map(str,args)],capture_output=True,text=True,preexec_fn=no_privileges)
    event(name,r.returncode==0,stdout=r.stdout,stderr=r.stderr,exit=r.returncode)
DENY='''import os,sys,json
try:
 OP
except OSError as e:
 print(json.dumps(dict(errno=e.errno,error=str(e))))
 sys.exit(0 if e.errno in (1,13) else 2)
sys.exit(3)
'''
def denied_ops(label):
    for p in FILES:
        for op,code in [('write',"fd=os.open(sys.argv[1],os.O_WRONLY);os.pwrite(fd,b'X',0);os.close(fd)"),('unlink','os.unlink(sys.argv[1])'),('rename',"os.rename(sys.argv[1],sys.argv[1]+'.renamed')")]:
            negative(label+'_'+p.name+'_'+op,DENY.replace('OP',code),[p])
def protection_state(expected):
    try:
        with parent_chain() as (pins,fd):
            if pins!=expected.get('parent_chain'):return 'BLOCKED_PARENT_CHAIN_DRIFT'
            actual=[pinned_file_identity(fd,p.name) for p in FILES]
            if not all(all(a[k]==e[k] for k in ['dev','ino','size','sha256','nlink']) for a,e in zip(actual,expected['files'])):return 'BLOCKED_IDENTITY'
            if not all(a['flags']&16 for a in actual):return 'BLOCKED_PARTIAL'
            # Detect a name-chain change during the observation as well.
            with parent_chain() as (again,_):
                if again!=pins:return 'BLOCKED_PARENT_CHAIN_DRIFT'
            return 'PROTECTED'
    except OSError:return 'BLOCKED_PARENT_OR_FILE_UNAVAILABLE'
def setup():
    assert not ROOT.exists(), 'fresh fixture required'
    ROOT.mkdir(mode=0o755);DATA.mkdir(mode=0o777);os.chmod(DATA,0o777)
    for i,p in enumerate(FILES):
        db=sqlite3.connect(p);db.execute('create table fixture(id integer primary key, value text)');db.execute('insert into fixture values(1,?)',('synthetic-'+str(i),));db.commit();db.close();os.chmod(p,0o666)
    (ROOT/'unrelated.txt').write_text('initial');os.chmod(ROOT/'unrelated.txt',0o666)
    facts={'files':[ident(p) for p in FILES],'parent':[DATA.stat().st_dev,DATA.stat().st_ino],'root':[ROOT.stat().st_dev,ROOT.stat().st_ino],'parent_chain':pin_parent_chain(),'boot':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'fs':subprocess.check_output(['findmnt','-n','-o','FSTYPE','-T',str(DATA)]).decode().strip()}
    event('real_ext4_distinct_inodes',facts['fs']=='ext4' and facts['files'][0]['ino']!=facts['files'][1]['ino'],facts=facts)
    alias=DATA/'alias.sqlite';os.link(FILES[0],alias)
    event('hardlink_alias_detected',ident(FILES[0])['nlink']==2 and alias.stat().st_ino==FILES[0].stat().st_ino)
    alias.unlink()
    helper_code='''import os,sys
fd=os.open(sys.argv[1],os.O_RDWR)
print('READY',flush=True)
for line in sys.stdin:
 if line.strip()=='WRITE':
  try:
   b=os.pread(fd,1,100);os.pwrite(fd,b,100);os.fsync(fd);print('WROTE',flush=True)
  except OSError as e: print('DENIED:'+str(e.errno),flush=True)
'''
    helper=subprocess.Popen([sys.executable,'-u','-c',helper_code,str(FILES[0])],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,preexec_fn=no_privileges)
    try:
        assert helper.stdout.readline().strip()=='READY'
        r=chattr(FILES[0]);installed=bool(flags(FILES[0])&16)
        helper.stdin.write('WRITE\n');helper.stdin.flush();outcome=helper.stdout.readline().strip()
        event('old_writable_fd_actual_kernel_behavior',(r.returncode!=0 and not installed and outcome=='WROTE') or (r.returncode==0 and installed and outcome in ['DENIED:1','DENIED:13']),install_exit=r.returncode,stderr=r.stderr,installed=installed,old_fd_outcome=outcome,note='Rejected installation means no fence; accepted installation must deny old FD. Helper is drained before final two-file acceptance.')
    finally:helper.kill();helper.wait()
    for p in FILES:
        r=chattr(p);event('install_'+p.name,r.returncode==0 and bool(flags(p)&16),exit=r.returncode,stderr=r.stderr)
    denied_ops('protected_world_writable_parent')
    # Ordinary actor can rename a writable parent only if its ancestor permits it.
    negative('root_owned_ancestor_denies_parent_swap',DENY.replace('OP',"os.rename(sys.argv[1],sys.argv[1]+'.moved')"),[DATA])
    negative('ordinary_unrelated_remains_writable',"import pathlib,sys;pathlib.Path(sys.argv[1]).write_text('still-writable');print('WROTE')",[ROOT/'unrelated.txt'])
    event('content_and_identity_stable',all(check_same(p,e) for p,e in zip(FILES,facts['files'])))
    # Authorized fixture admin replacement shows flags alone do not protect parent names.
    moved=ROOT/'moved';DATA.rename(moved);DATA.mkdir(mode=0o755)
    for p in FILES:p.write_bytes(b'replacement-only')
    event('parent_replacement_is_detected',protection_state(facts)=='BLOCKED_PARENT_CHAIN_DRIFT')
    for p in FILES:p.unlink()
    DATA.rmdir();moved.rename(DATA)
    copy=ROOT/'copy.sqlite';copy.write_bytes(FILES[0].read_bytes());event('copy_not_original',not check_same(copy,facts['files'][0]));copy.unlink()
    link=ROOT/'linked-parent';link.symlink_to(DATA,target_is_directory=True)
    event('symlink_parent_is_classified_alias',link.is_symlink() and (link/FILES[0].name).stat().st_ino==FILES[0].stat().st_ino);link.unlink()
    # Independently invoke a fresh process after protection; no helper/controller owns the flag.
    r=subprocess.run([sys.executable,'-c',"import os,sys;f=os.open(sys.argv[1],os.O_WRONLY)",str(FILES[0])],preexec_fn=no_privileges,capture_output=True,text=True)
    event('new_writer_process_denied',r.returncode!=0,stderr=r.stderr)
    # Fixture-only authorized partial-protection setup. Never implicitly release the other inode.
    r=chattr(FILES[1],False);event('explicit_fixture_partial_setup',r.returncode==0)
    r=subprocess.run(['chattr','+i',str(FILES[1])],preexec_fn=no_privileges,capture_output=True,text=True)
    event('partial_failure_detected_no_implicit_unlock',r.returncode!=0 and protection_state(facts)=='BLOCKED_PARTIAL' and bool(flags(FILES[0])&16),exit=r.returncode,stderr=r.stderr,failure_injection='real unprivileged actor; no mocked ioctl')
    r=chattr(FILES[1]);event('explicit_fixture_reprotect_after_drain',r.returncode==0 and protection_state(facts)=='PROTECTED')
    os.chmod(DATA,0o755)
    facts['parent_chain']=pin_parent_chain()
    STATE.write_text(json.dumps(facts,indent=2));os.sync()
def verify():
    facts=json.loads(STATE.read_text());event('both_original_inodes_still_protected',protection_state(facts)=='PROTECTED',files=[ident(p) for p in FILES])
    denied_ops('restart')
    event('unrelated_write_after_restart',subprocess.run(['sh','-c','echo reboot-ok >> '+str(ROOT/'unrelated.txt')],preexec_fn=no_privileges).returncode==0)
    event('guest_boot_changed',pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=facts['boot'])
def cleanup():
    facts=json.loads(STATE.read_text());assert protection_state(facts)=='PROTECTED'
    for p in FILES:
        r=chattr(p,False);event('bounded_fixture_release_'+p.name,r.returncode==0 and not flags(p)&16)
    for p in FILES:
        negative('released_fixture_write_'+p.name,"import os,sys;f=os.open(sys.argv[1],os.O_RDWR);b=os.pread(f,1,100);os.pwrite(f,b,100);os.close(f)",[p])
    for p in FILES:p.unlink()
    DATA.rmdir();STATE.unlink();(ROOT/'unrelated.txt').unlink();ROOT.rmdir()
    event('fixture_removed',not ROOT.exists())
if __name__=='__main__':
    try:
        {'setup':setup,'verify':verify,'cleanup':cleanup}[sys.argv[1]]()
        print(json.dumps({'status':'PASS','phase':sys.argv[1],'results':RESULT}))
    except Exception as e:
        print(json.dumps({'status':'FAIL','phase':sys.argv[1],'error':str(e),'results':RESULT}));sys.exit(1)
