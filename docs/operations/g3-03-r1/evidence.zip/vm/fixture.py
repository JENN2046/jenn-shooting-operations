import sqlite3
def fixture(path, *, reverse=False, additional=False, duplicate=False, changed_type=False,
            changed_rowid=False, index_desc=False, malformed=False, application_id=12):
    db = sqlite3.connect(str(path))
    try:
        db.execute("PRAGMA journal_mode=DELETE")
        db.execute("PRAGMA application_id=" + str(application_id))
        db.executescript("""
          CREATE TABLE schema_migrations
            (version INTEGER PRIMARY KEY, name TEXT NOT NULL, checksum TEXT NOT NULL, applied_at TEXT NOT NULL);
          CREATE TABLE records (id INTEGER PRIMARY KEY AUTOINCREMENT, txt TEXT, blob BLOB, nullable TEXT, amount REAL);
          CREATE TABLE repeated (entry TEXT, raw BLOB);
          CREATE INDEX records_amount_idx ON records(amount);
        """)
        for i in range(1, 11):
            db.execute("INSERT INTO schema_migrations VALUES (?,?,?,?)",
                       (i, "migration_" + str(i), "sha256:" + ("b" * 64), "2026-10-01T00:00:00.000Z"))
        for i in ([2, 1] if reverse else [1, 2]):
            db.execute("INSERT INTO records VALUES(?,?,?,?,?)", (i, "same", sqlite3.Binary(b"\x00\xff"), None, float(i)))
        db.execute("INSERT INTO repeated VALUES (?,?)", ("duplicate", sqlite3.Binary(b"z")))
        db.execute("INSERT INTO repeated VALUES (?,?)", ("duplicate", sqlite3.Binary(b"z")))
        if duplicate:
            db.execute("INSERT INTO repeated VALUES (?,?)", ("duplicate", sqlite3.Binary(b"z")))
        if changed_type:
            db.execute("UPDATE repeated SET raw=3 WHERE rowid=1")
        if changed_rowid:
            db.execute("DELETE FROM repeated WHERE rowid=1")
            db.execute("INSERT INTO repeated VALUES (?,?)", ("duplicate", sqlite3.Binary(b"z")))
        if index_desc:
            db.executescript("DROP INDEX records_amount_idx; CREATE INDEX records_amount_idx ON records(amount DESC);")
        if malformed:
            db.executescript('CREATE TABLE "bad;name" (value TEXT);')
        if additional:
            db.execute("INSERT INTO schema_migrations VALUES(?,?,?,?)",
                       (11, "test_migration_11", "sha256:" + ("c" * 64), "2026-10-08T00:00:00.000Z"))
            db.execute("CREATE TABLE additional_control (id TEXT)")
        db.commit()
    finally:
        db.close()

