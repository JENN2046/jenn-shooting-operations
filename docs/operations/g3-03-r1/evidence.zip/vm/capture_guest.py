import pathlib, sys, json, hashlib, os, time, fcntl, array
challenge=sys.argv[1]
assert len(challenge)==64 and all(c in '0123456789abcdef' for c in challenge)
# Disposable F1 acceptance fixture: a real delayed response, with unchanged SSH command.
delay_file=pathlib.Path('/opt/jso/fixture-delay-seconds')
if delay_file.exists():
    delay=float(delay_file.read_text());assert 0<=delay<=3
    time.sleep(delay)
def digest(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
import importlib.util
import e1_guest as custody
spec=importlib.util.spec_from_file_location('witness','/opt/jso/witness.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
expected=json.loads(custody.STATE.read_text())
assert custody.protection_state(expected)=='PROTECTED', 'CUSTODY_BEFORE_BLOCKED'
observation=w.capture(str(custody.FILES[1]),str(custody.FILES[0]),'synthetic')
assert observation['status']=='READONLY_OBSERVATION_NOT_AUTHORITY', 'SEMANTIC_REJECTED'
assert custody.protection_state(expected)=='PROTECTED', 'CUSTODY_AFTER_BLOCKED'
files=[]
for p in [pathlib.Path('/var/lib/jso-fixture/originals')/x for x in ['active.sqlite','preserved.sqlite']]:
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        s=os.fstat(fd);a=array.array('L',[0]);fcntl.ioctl(fd,0x80086601,a,True)
        h=hashlib.sha256()
        while b:=os.read(fd,65536):h.update(b)
        after=os.fstat(fd)
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
        files.append(dict(name=p.name,dev=s.st_dev,ino=s.st_ino,size=s.st_size,sha256=h.hexdigest(),immutable=bool(a[0]&16)))
    finally:os.close(fd)
out=dict(schema='JSO_NONPRODUCTION_CAPTURE_R1',challenge=challenge,instance_uuid=pathlib.Path('/sys/class/dmi/id/product_uuid').read_text().strip(),boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),code_sha256=digest(__file__),runtime_sha256=digest(os.path.realpath(sys.executable)),runtime=sys.version,uid=os.getuid(),timestamp=time.time(),files=files,scope='SYNTHETIC_BUSINESS_DATA_REAL_VM_SSH_NOT_PRODUCTION')
out.update(witness=observation,custody_before='PROTECTED',custody_after='PROTECTED')
print(json.dumps(out,sort_keys=True,separators=(',',':')))
print('JSO_CAPTURE_COMPLETE:'+challenge,file=sys.stderr)
