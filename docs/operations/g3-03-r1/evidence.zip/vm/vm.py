import pathlib, json, subprocess, os, socket, uuid, time, sys, hashlib
P = pathlib.Path(__file__).resolve().parent
C = json.loads((P/'run.json').read_text())
W = pathlib.Path(C['work'])
def run(args, **kw):
    return subprocess.run(args, check=True, **kw)
def ssh_args():
    return ['ssh','-F','/dev/null','-i',str(W/'client'),'-p',str(C['port']),
            '-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-o','BatchMode=yes',
            '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile="'+str(P/'known_hosts')+'"',
            '-o','GlobalKnownHostsFile=/dev/null','-o','UpdateHostKeys=no',
            '-o','ForwardAgent=no','-o','ClearAllForwardings=yes','-o','ConnectTimeout=5',
            'tester@127.0.0.1']
def start():
    cmd=['qemu-system-x86_64','-name','jso-disposable-'+C['run_id'][:8],
         '-uuid',C['run_id'],'-machine','q35,accel=kvm','-cpu','host','-smp','2','-m','2048',
         '-nodefaults','-no-user-config','-display','none','-monitor','none',
         '-serial','file:'+str(W/'serial.log'),'-qmp','unix:'+str(W/'qmp.sock')+',server=on,wait=off',
         '-drive','file='+str(W/'disk.qcow2')+',if=virtio,format=qcow2',
         '-drive','file='+str(W/'seed.iso')+',if=virtio,format=raw,readonly=on',
         '-netdev','user,id=net0,restrict=on,ipv6=off,hostfwd=tcp:127.0.0.1:'+str(C['port'])+'-:22',
         '-device','virtio-net-pci,netdev=net0',
         '-sandbox','on,obsolete=deny,elevateprivileges=deny,spawn=deny,resourcecontrol=deny',
         '-pidfile',str(W/'qemu.pid')]
    with (P/'qemu-launches.jsonl').open('a') as f: f.write(json.dumps({'utc':time.time(),'argv':cmd})+'\n')
    with (P/'qemu-runtime.log').open('a') as log:
        proc=subprocess.Popen(cmd,stdout=log,stderr=log,start_new_session=True)
    time.sleep(.5)
    if proc.poll() is not None:raise RuntimeError('QEMU startup failed: '+str(proc.returncode))
def setup():
    assert (P/'image-verified.json').exists()
    with socket.socket() as s: s.bind(('127.0.0.1',0)); C['port']=s.getsockname()[1]
    (P/'run.json').write_text(json.dumps(C,indent=2)+'\n')
    run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(W/'client')])
    public=(W/'client.pub').read_text().strip()
    userdata='''#cloud-config
users:
  - name: tester
    lock_passwd: true
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
    ssh_authorized_keys:
      - PUBLIC_KEY
ssh_pwauth: false
disable_root: true
package_update: false
package_upgrade: false
write_files:
  - path: /etc/ssh/sshd_config.d/01-jso-fixture.conf
    permissions: '0644'
    content: |
      PasswordAuthentication no
      KbdInteractiveAuthentication no
      AllowUsers tester
      AllowAgentForwarding no
      AllowTcpForwarding no
      X11Forwarding no
runcmd:
  - [sh, -c, 'echo JSO_HOSTKEY_BEGIN > /dev/ttyS0; cat /etc/ssh/ssh_host_ed25519_key.pub > /dev/ttyS0; echo JSO_HOSTKEY_END > /dev/ttyS0']
  - [sh, -c, 'echo JSO_READY > /dev/ttyS0']
'''.replace('PUBLIC_KEY',public)
    (W/'user-data').write_text(userdata)
    (W/'meta-data').write_text('instance-id: '+C['run_id']+'\nlocal-hostname: jso-disposable\n')
    run(['cloud-localds',str(W/'seed.iso'),str(W/'user-data'),str(W/'meta-data')])
    run(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(W/'base.img'),str(W/'disk.qcow2'),'8G'])
    start()
def ready():
    raw=(W/'serial.log').read_text(errors='replace')
    if not (P/'known_hosts').exists():
        assert '\nJSO_READY' in raw or '\r\nJSO_READY' in raw, 'cloud-init not ready'
        part=raw.split('JSO_HOSTKEY_BEGIN')[-1].split('JSO_HOSTKEY_END')[0]
        key=next(x.strip() for x in part.splitlines() if x.startswith('ssh-ed25519 '))
        (P/'known_hosts').write_text('[127.0.0.1]:'+str(C['port'])+' '+key+'\n')
        (P/'serial-bootstrap.txt').write_text(raw)
        (P/'hostkey-binding.json').write_text(json.dumps({'uuid':C['run_id'],'public_key':key,'source':'direct QEMU serial of locally launched UUID; pinned before first SSH; no ssh-keyscan/TOFU'},indent=2)+'\n')
    r=run(ssh_args()+['sudo -n python3 -c "import pathlib,json,platform,subprocess; print(json.dumps(dict(uuid=pathlib.Path(\'/sys/class/dmi/id/product_uuid\').read_text().strip(),boot_id=pathlib.Path(\'/proc/sys/kernel/random/boot_id\').read_text().strip(),kernel=platform.release(),fs=subprocess.check_output([\'findmnt\',\'-n\',\'-o\',\'FSTYPE\',\'/\']).decode().strip())))"'],capture_output=True,text=True)
    d=json.loads(r.stdout); assert d['uuid'].lower()==C['run_id'].lower(); assert d['fs']=='ext4'
    print(json.dumps(d))
    with (P/'guest-boots.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
if __name__=='__main__':
    {'setup':setup,'start':start,'ready':ready}[sys.argv[1]]()
