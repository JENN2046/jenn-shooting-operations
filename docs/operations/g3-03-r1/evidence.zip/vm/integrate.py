import json,sys,pathlib,hashlib,shlex,copy,sqlite3,time,subprocess
from vm import P,W,C,ssh_args
from operate import execute
import e2_host as e
expected_path=P/'expected-capture.json'
def initialize():
    r=execute('pins-integrated','sudo -n python3 -c '+shlex.quote("import sys,pathlib,json,hashlib,os,sqlite3; print(json.dumps(dict(files=json.loads(pathlib.Path('/var/lib/jso-fixture/state.json').read_text())['files'],runtime_sha256=hashlib.sha256(pathlib.Path(os.path.realpath(sys.executable)).read_bytes()).hexdigest(),witness_sha256='sha256:'+hashlib.sha256(pathlib.Path('/opt/jso/witness.py').read_bytes()).hexdigest(),witness_runtime=dict(python=sys.version.split()[0],sqlite=sqlite3.sqlite_version))))"))
    d=json.loads(r.stdout);d.update(code_sha256=e.sha((P/'capture_guest.py').read_bytes()),hostkey_sha256=e.sha((P/'known_hosts').read_bytes()),uid=0,scope='SYNTHETIC_BUSINESS_DATA_REAL_VM_SSH_NOT_PRODUCTION')
    assert d['witness_sha256']=='sha256:'+e.sha((P.parent/'repo/scripts/g3-forward-adoption-readonly-witness.py').read_bytes())
    expected_path.write_text(json.dumps(d,indent=2))
def phase(label):
    d=json.loads(expected_path.read_text());results=[]
    def check(name,fn):
        fn();results.append({'case':name,'pass':True})
    def reject(fn,match):
        try:fn()
        except Exception as exc:
            assert match in str(exc),(match,str(exc));return
        raise AssertionError('unexpected acceptance')
    n=e.issue();r=e.capture(n,d);check('real_ssh_ext4_wal_witness_'+label,lambda:e.validate(r,n,d))
    if label=='initial':
        check('replay_bound_to_integrated_capture',lambda:reject(lambda:e.capture(n,d),'REPLAY'))
        edits={
          'witness_code':lambda x:x['witness'].update(verifierSha256='sha256:'+'0'*64),
          'witness_runtime':lambda x:x['witness']['runtime'].update(sqlite='wrong'),
          'witness_raw_binding':lambda x:x['witness']['fileIdentities']['active'].update(inode=0),
          'custody_missing':lambda x:x.update(custody_after='UNKNOWN'),
        }
        for name,edit in edits.items():
            rr=copy.deepcopy(r);data=json.loads(rr['stdout']);edit(data);rr['stdout']=json.dumps(data)
            check('record_copy_'+name,lambda rr=rr:reject(lambda:e.validate(rr,n,d),{'witness_code':'RUNTIME_BINDING','witness_runtime':'RUNTIME_BINDING','witness_raw_binding':'WITNESS_DIGEST','custody_missing':'CUSTODY_BINDING'}[name]))
        # Recomputed digest cannot hide different fd binding from the authenticated outer capture.
        rr=copy.deepcopy(r);data=json.loads(rr['stdout']);obs=data['witness'];obs['fileIdentities']['active']['inode']=0
        raw={k:v for k,v in obs.items() if k not in ['captureDigest','status']};obs['captureDigest']='sha256:'+e.sha(json.dumps(raw,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());rr['stdout']=json.dumps(data)
        check('record_copy_rehashed_wrong_fd',lambda:reject(lambda:e.validate(rr,n,d),'CROSS_COMPONENT_FILE_BINDING'))
        execute('delay-on','sudo -n sh -c '+shlex.quote('echo 2 > /opt/jso/fixture-delay-seconds'))
        late=e.issue(1);check('real_integrated_reply_expired',lambda:reject(lambda:e.capture(late,d),'EXPIRED_AT_COMPLETION'))
        execute('delay-off','sudo -n rm /opt/jso/fixture-delay-seconds')
        lost=e.issue();check('real_response_loss',lambda:reject(lambda:e.capture(lost,d,command='sleep 3',timeout=.5),'MISSING_OR_NONZERO_EXIT'))
        check('lost_identity_consumed',lambda:reject(lambda:e.consume(lost),'REPLAY'))
        execute('partial-protection-on','sudo -n chattr -i /var/lib/jso-fixture/originals/preserved.sqlite')
        try:
            check('real_partial_custody_blocks_capture',lambda:reject(lambda:e.capture(e.issue(),d),'MISSING_OR_NONZERO_EXIT'))
        finally:execute('partial-protection-restore','sudo -n chattr +i /var/lib/jso-fixture/originals/preserved.sqlite')
        execute('parent-permission-drift','sudo -n chmod 0700 /var/lib/jso-fixture/originals')
        try:check('real_parent_drift_blocks_capture',lambda:reject(lambda:e.capture(e.issue(),d),'MISSING_OR_NONZERO_EXIT'))
        finally:execute('parent-permission-restore','sudo -n chmod 0755 /var/lib/jso-fixture/originals')
        check('restored_custody_integrated_control',lambda:e.capture(e.issue(),d))
    check('strict_readback_'+label,lambda:e.readback())
    (P/('integration-'+label+'.json')).write_text(json.dumps({'results':results,'count':len(results),'pass':True,'readback_records':e.readback()},indent=2))
    print(json.dumps({'phase':label,'count':len(results),'pass':True}))
if __name__=='__main__':
    if sys.argv[1]=='init':initialize()
    else:phase(sys.argv[1])
