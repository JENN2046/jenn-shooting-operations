"""Disposable acceptance harness only; no production authority or service."""
import pathlib, json, subprocess, sqlite3, secrets, time, hashlib, os, sys, copy
from vm import P, W, C, ssh_args
E=P/'e2'
DB=E/'nonce.sqlite'
def sha(b):return hashlib.sha256(b).hexdigest()
def connect():
    DB.parent.mkdir(mode=0o700,exist_ok=True)
    d=sqlite3.connect(DB);d.execute('PRAGMA synchronous=FULL')
    d.execute('CREATE TABLE IF NOT EXISTS nonce(n TEXT PRIMARY KEY, issued REAL, expires REAL, consumed INTEGER NOT NULL, status TEXT, digest TEXT, consumed_at REAL, terminal_at REAL)');d.commit();os.chmod(DB,0o600);return d
def issue(ttl=300):
    n=secrets.token_hex(32)
    now=time.time()
    with connect() as d:d.execute('INSERT INTO nonce VALUES(?,?,?,?,?,?,?,?)',(n,now,now+ttl,0,'ISSUED',None,None,None))
    return n
def consume(n):
    with connect() as d:
        d.execute('BEGIN IMMEDIATE');row=d.execute('SELECT issued,expires,consumed FROM nonce WHERE n=?',(n,)).fetchone()
        if not row:raise ValueError('UNKNOWN_NONCE')
        if row[2]:raise ValueError('REPLAY')
        now=time.time();deadline_mono=time.monotonic()+max(0,row[1]-now)
        d.execute('UPDATE nonce SET consumed=1,status=?,consumed_at=? WHERE n=?',('CONSUMED_BEFORE_TRANSPORT',now,n))
    if now<row[0]:raise ValueError('HOST_TIME_UNKNOWN')
    if now>=row[1]:
        finish(n,'REJECTED:EXPIRED');raise ValueError('EXPIRED')
    return row[0],row[1],deadline_mono
def finish(n,status,digest=None,deadline_mono=None):
    with connect() as d:
        d.execute('BEGIN IMMEDIATE')
        row=d.execute('SELECT issued,expires,consumed,status FROM nonce WHERE n=?',(n,)).fetchone()
        if not row or row[2]!=1 or row[3]!='CONSUMED_BEFORE_TRANSPORT':raise ValueError('TERMINAL_TRANSITION_INVALID')
        now=time.time()
        if status=='ACCEPTED':
            if not digest:raise ValueError('MISSING_RECEIPT_DIGEST')
            if deadline_mono is None or not row[0]<=now<row[1] or time.monotonic()>=deadline_mono:raise ValueError('EXPIRED_AT_ACCEPTANCE')
        d.execute('UPDATE nonce SET status=?,digest=?,terminal_at=? WHERE n=?',(status,digest,now,n))
def validate(rec,n,expected):
    if rec.get('exit')!=0:raise ValueError('MISSING_OR_NONZERO_EXIT')
    if rec.get('hostkey_sha256')!=expected['hostkey_sha256']:raise ValueError('HOSTKEY_BINDING')
    if rec.get('transport')!='OPENSSH_STRICT_PINNED_NO_AGENT':raise ValueError('TRANSPORT')
    if rec.get('argv')!=ssh_args()+['sudo -n python3 /opt/jso/capture_guest.py '+n]:raise ValueError('COMMAND_OR_EXECUTION_IDENTITY')
    if 'stdout' not in rec or 'stderr' not in rec:raise ValueError('MISSING_OUTPUT')
    raw=rec['stdout'];data=json.loads(raw)
    if data.get('challenge')!=n:raise ValueError('CHALLENGE')
    if data.get('instance_uuid','').lower()!=C['run_id'].lower():raise ValueError('INSTANCE')
    for k in ['code_sha256','runtime_sha256','uid','scope']:
        if data.get(k)!=expected[k]:raise ValueError(k)
    if abs(time.time()-data['timestamp'])>300:raise ValueError('STALE_CAPTURE')
    if not rec['stderr'].endswith('JSO_CAPTURE_COMPLETE:'+n+'\n'):raise ValueError('INCOMPLETE_STDERR')
    f=data['files'];pins=expected['files']
    if len(f)!=2 or {(x['dev'],x['ino']) for x in f}.__len__()!=2:raise ValueError('TWO_DISTINCT_INODES')
    for x,p in zip(f,pins):
        if any(x.get(k)!=p[k] for k in ['dev','ino','size','sha256']) or x.get('immutable') is not True:raise ValueError('FILE_BINDING')
    if data.get('custody_before')!='PROTECTED' or data.get('custody_after')!='PROTECTED':raise ValueError('CUSTODY_BINDING')
    observation=data['witness']
    if observation['verifierSha256']!=expected['witness_sha256'] or observation['runtime']!=expected['witness_runtime']:raise ValueError('WITNESS_RUNTIME_BINDING')
    if observation['status']!='READONLY_OBSERVATION_NOT_AUTHORITY' or observation['problems'] or observation['profile']!='synthetic':raise ValueError('WITNESS_STATUS')
    if any(observation[k] is not False for k in ['adoptionAuthorityAllowed','writerReadmissionAllowed','serviceStartAllowed','g4Allowed']):raise ValueError('AUTHORITY_ESCALATION')
    raw_observation={k:v for k,v in observation.items() if k not in ['captureDigest','status']}
    canonical=json.dumps(raw_observation,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
    if observation['captureDigest']!='sha256:'+sha(canonical):raise ValueError('WITNESS_DIGEST')
    for side,x in zip(['active','prestate'],f):
        ident=observation['fileIdentities'][side]
        if (ident['device'],ident['inode'],ident['size'],ident['sha256'])!=(x['dev'],x['ino'],x['size'],'sha256:'+x['sha256']):raise ValueError('CROSS_COMPONENT_FILE_BINDING')
    return data
def capture(n,expected,args=None,command=None,timeout=30):
    issued,expires,deadline_mono=consume(n)
    argv=args or ssh_args()
    remote=command or 'sudo -n python3 /opt/jso/capture_guest.py '+n
    start=time.time();start_mono=time.monotonic()
    try:
        r=subprocess.run(argv+[remote],capture_output=True,timeout=timeout)
        rec={'challenge':n,'argv':argv+[remote],'started':start,'finished':time.time(),'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'transport':'OPENSSH_STRICT_PINNED_NO_AGENT','hostkey_sha256':expected['hostkey_sha256']}
    except subprocess.TimeoutExpired as e:
        rec={'challenge':n,'started':start,'finished':time.time(),'exit':None,'stdout':(e.stdout or b'').decode(),'stderr':(e.stderr or b'').decode(),'timeout':True}
    rec.update(issued=issued,expires=expires,elapsed_monotonic=time.monotonic()-start_mono,remaining_monotonic_at_start=deadline_mono-start_mono)
    raw=json.dumps(rec,sort_keys=True,indent=2).encode();path=E/(n+'.json')
    with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.chmod(path,0o400)
    directory=os.open(E,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(directory)
    finally:os.close(directory)
    digest=sha(raw)
    try:
        if not issued<=start<=rec['finished']<expires or rec['elapsed_monotonic']>=rec['remaining_monotonic_at_start']:raise ValueError('EXPIRED_AT_COMPLETION')
        validate(rec,n,expected);finish(n,'ACCEPTED',digest,deadline_mono);return rec
    except Exception as e:finish(n,'REJECTED:'+str(e),digest);raise
def readback(db_path=DB,records_dir=E):
    # Never create or update the ledger during evidence verification.
    with sqlite3.connect(pathlib.Path(db_path).resolve().as_uri()+'?mode=ro',uri=True) as d:
        if d.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('LEDGER_CORRUPT')
        rows=d.execute('SELECT n,issued,expires,consumed,status,digest,consumed_at,terminal_at FROM nonce').fetchall()
    for n,issued,expires,consumed,status,digest,consumed_at,terminal_at in rows:
        if consumed!=1 or consumed_at is None or terminal_at is None:raise ValueError('INCOMPLETE_TERMINAL')
        if not issued<=consumed_at<=terminal_at:raise ValueError('HOST_TIME_UNKNOWN')
        path=pathlib.Path(records_dir)/(n+'.json')
        if status=='REJECTED:EXPIRED':
            if consumed_at<expires or digest is not None or path.exists():raise ValueError('INVALID_PRETRANSPORT_REJECTION')
            continue
        if status not in ['ACCEPTED','REJECTED:EXPIRED_AT_COMPLETION','REJECTED:EXPIRED_AT_ACCEPTANCE','REJECTED:MISSING_OR_NONZERO_EXIT']:raise ValueError('UNKNOWN_TERMINAL')
        if not digest or not path.is_file() or path.is_symlink():raise ValueError('MISSING_RECEIPT')
        raw=path.read_bytes()
        if sha(raw)!=digest:raise ValueError('CUSTODY_DIGEST_MISMATCH')
        rec=json.loads(raw)
        if rec.get('challenge')!=n or rec.get('issued')!=issued or rec.get('expires')!=expires:raise ValueError('RECEIPT_LEDGER_BINDING')
        if not consumed_at<=rec['started']<=rec['finished']<=terminal_at:raise ValueError('RECEIPT_TIME_ORDER')
        if status=='ACCEPTED':
            if rec.get('exit')!=0 or not terminal_at<expires:raise ValueError('ACCEPTED_CONTRACT_INVALID')
        elif status=='REJECTED:EXPIRED_AT_COMPLETION':
            if rec['finished']<expires and rec.get('elapsed_monotonic',-1)<rec.get('remaining_monotonic_at_start',float('inf')):raise ValueError('EXPIRY_NOT_EVIDENCED')
        elif status=='REJECTED:EXPIRED_AT_ACCEPTANCE':
            if terminal_at<expires:raise ValueError('EXPIRY_NOT_EVIDENCED')
        elif rec.get('exit')==0 or (rec.get('exit') is None and not rec.get('timeout')):raise ValueError('REJECTION_NOT_EVIDENCED')
    return len(rows)
def main():
    expected=json.loads((P/'expected-capture.json').read_text());results=[]
    def check(name,func):
        try:func();results.append({'case':name,'pass':True})
        except Exception as e:results.append({'case':name,'pass':False,'error':str(e)});raise
    def reject(func,match=None):
        try:func()
        except Exception as e:
            if match and match not in str(e):raise
            return
        raise AssertionError('unexpected acceptance')
    n=issue();rec=capture(n,expected);results.append({'case':'real_pinned_ssh_capture','pass':True})
    check('same_nonce_replay_rejected',lambda:reject(lambda:capture(n,expected),'REPLAY'))
    # A separate collector process must also observe the durable consumed state.
    r=subprocess.run([sys.executable,__file__,'consume',n],capture_output=True,text=True)
    check('restart_replay_rejected',lambda: (_ for _ in ()).throw(AssertionError(r.stdout+r.stderr)) if r.returncode==0 else None)
    old=issue(-1);check('expired_nonce_rejected_before_transport',lambda:reject(lambda:capture(old,expected),'EXPIRED'))
    # Real transport rejection with an intentionally wrong pinned key; no trust-on-first-use.
    subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(W/'wrong-pin')],check=True)
    wrong=W/'wrong-known-hosts';wrong.write_text('[127.0.0.1]:'+str(C['port'])+' '+(W/'wrong-pin.pub').read_text())
    a=ssh_args();a[a.index('UserKnownHostsFile="'+str(P/'known_hosts')+'"')]='UserKnownHostsFile='+str(wrong)
    bad=issue();check('real_wrong_hostkey_connection_rejected',lambda:reject(lambda:capture(bad,expected,args=a),'MISSING_OR_NONZERO_EXIT'))
    a=ssh_args();a[-1]='unauthorized-fixture-user@127.0.0.1'
    bad=issue();check('real_unexpected_actor_rejected',lambda:reject(lambda:capture(bad,expected,args=a),'MISSING_OR_NONZERO_EXIT'))
    lost=issue();check('real_response_loss_timeout_rejected',lambda:reject(lambda:capture(lost,expected,command='sleep 10',timeout=1),'MISSING_OR_NONZERO_EXIT'))
    check('response_loss_nonce_not_retried',lambda:reject(lambda:capture(lost,expected),'REPLAY'))
    bad=issue();check('real_nonzero_exit_rejected',lambda:reject(lambda:capture(bad,expected,command='exit 23'),'MISSING_OR_NONZERO_EXIT'))
    # Mutations of an actual captured transcript, not simulated SSH. Preserve originals.
    edits={
      'rebound_instance':lambda d:d.update(instance_uuid='00000000-0000-0000-0000-000000000000'),
      'rebound_challenge':lambda d:d.update(challenge='0'*64),
      'altered_code':lambda d:d.update(code_sha256='0'*64),
      'altered_runtime':lambda d:d.update(runtime_sha256='0'*64),
      'stale_timestamp':lambda d:d.update(timestamp=0),
      'wrong_uid':lambda d:d.update(uid=65534),
      'altered_file_digest':lambda d:d['files'][0].update(sha256='0'*64),
      'same_inode_twice':lambda d:d['files'].__setitem__(1,copy.deepcopy(d['files'][0])),
      'missing_immutable':lambda d:d['files'][1].update(immutable=False),
    }
    for name,edit in edits.items():
        changed=copy.deepcopy(rec);data=json.loads(changed['stdout']);edit(data);changed['stdout']=json.dumps(data)
        check('transcript_mutation_'+name,lambda c=changed:reject(lambda:validate(c,n,expected)))
    for field in ['exit','stdout','stderr']:
        changed=copy.deepcopy(rec);del changed[field]
        check('missing_'+field,lambda c=changed:reject(lambda:validate(c,n,expected)))
    changed=copy.deepcopy(rec);changed['stderr']='truncated\n';check('tampered_stderr',lambda:reject(lambda:validate(changed,n,expected)))
    changed=copy.deepcopy(rec);changed['argv'][-1]='echo forged';check('tampered_command',lambda:reject(lambda:validate(changed,n,expected)))
    altered=E/'tampered-copy.json';altered.write_bytes((E/(n+'.json')).read_bytes()+b' ')
    with connect() as d:original_digest=d.execute('SELECT digest FROM nonce WHERE n=?',(n,)).fetchone()[0]
    check('archive_byte_tampering_detected',lambda:(_ for _ in ()).throw(AssertionError('tamper undetected')) if sha(altered.read_bytes())==original_digest else None)
    # This is a modified copy, explicitly retained outside the authoritative nonce archive.
    os.chmod(altered,0o400)
    # Verify archival integrity using a separate process and durable ledger.
    r=subprocess.run([sys.executable,__file__,'readback'],capture_output=True,text=True)
    check('independent_process_readback',lambda:(_ for _ in ()).throw(AssertionError(r.stdout+r.stderr)) if r.returncode else None)
    (P/'e2-results.json').write_text(json.dumps({'results':results,'count':len(results),'pass':all(x['pass'] for x in results),'readback':r.stdout,'distinction':'real SSH negative connections plus explicitly labelled mutations of real transcript; host custodian separate from guest, same trusted host admin'},indent=2)+'\n')
    print(json.dumps({'count':len(results),'pass':True}))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='consume':consume(sys.argv[2])
    elif len(sys.argv)>1 and sys.argv[1]=='readback':print(json.dumps({'verified_consumed_records':readback()}))
    else:main()
