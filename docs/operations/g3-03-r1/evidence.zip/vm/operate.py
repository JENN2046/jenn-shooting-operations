import pathlib,json,subprocess,sys,time,hashlib,os,signal,socket,shlex
from vm import P,W,C,ssh_args
def execute(label,command,input=None,timeout=90):
    r=subprocess.run(ssh_args()+[command],input=input,capture_output=True,timeout=timeout)
    record={'label':label,'utc':time.time(),'argv':ssh_args()+[command],'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')}
    path=P/(label+'.json');assert not path.exists(), 'do not overwrite previous evidence'
    path.write_text(json.dumps(record,indent=2)+'\n');print(label,'exit',r.returncode);print(record['stdout']);print(record['stderr'])
    r.check_returncode();return r
def upload():
    execute('create-guest-tools','sudo -n install -d -m 0755 /opt/jso')
    for f in ['e1_guest.py','capture_guest.py']:
        execute('upload-'+f,'sudo -n sh -c '+shlex.quote('cat > /opt/jso/'+f),(P/f).read_bytes())
    execute('guest-tool-pins','sudo -n sha256sum /opt/jso/e1_guest.py /opt/jso/capture_guest.py /usr/bin/python3.12')
def phase(name):return execute('e1-'+name,'sudo -n python3 /opt/jso/e1_guest.py '+('verify' if name.startswith('verify') else name))
def pin():
    r=execute('capture-pins','sudo -n python3 -c '+shlex.quote("import json,pathlib,hashlib,sys,os; print(json.dumps(dict(files=json.loads(pathlib.Path('/var/lib/jso-fixture/state.json').read_text())['files'],runtime_sha256=hashlib.sha256(pathlib.Path(os.path.realpath(sys.executable)).read_bytes()).hexdigest())))"))
    d=json.loads(r.stdout);d.update(code_sha256=hashlib.sha256((P/'capture_guest.py').read_bytes()).hexdigest(),hostkey_sha256=hashlib.sha256((P/'known_hosts').read_bytes()).hexdigest(),uid=0,scope='SYNTHETIC_BUSINESS_DATA_REAL_VM_SSH_NOT_PRODUCTION')
    (P/'expected-capture.json').write_text(json.dumps(d,indent=2)+'\n')
def isolation():
    # Only a fresh listener owned by this harness is probed; no host services are scanned.
    with socket.socket() as server:
        server.bind(('127.0.0.1',0));server.listen();port=server.getsockname()[1]
        script="import socket,json,pathlib,subprocess; s=socket.socket();s.settimeout(2); rc=s.connect_ex(('10.0.2.2',"+str(port)+")); print(json.dumps(dict(connect_to_controlled_host_listener=rc,host_evidence_visible=pathlib.Path("+repr(str(P))+ ").exists(),mounts=subprocess.check_output(['findmnt','-rn','-o','FSTYPE,SOURCE,TARGET']).decode()))); assert rc!=0; assert not pathlib.Path("+repr(str(P))+").exists()"
        execute('guest-isolation','sudo -n python3 -c '+shlex.quote(script))
        server.settimeout(.2)
        try:server.accept();raise AssertionError('guest reached host listener')
        except socket.timeout:pass
    pid=int((W/'qemu.pid').read_text());args=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
    assert C['run_id'].encode() in args
    (P/'qemu-process.json').write_text(json.dumps({'pid':pid,'uid':os.stat(f'/proc/{pid}').st_uid,'argv':[os.fsdecode(x) for x in args if x]},indent=2)+'\n')
def crash():
    pid=int((W/'qemu.pid').read_text());args=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0');assert C['run_id'].encode() in args
    os.kill(pid,signal.SIGKILL)
    (P/'qemu-crash.json').write_text(json.dumps({'pid':pid,'signal':'SIGKILL','utc':time.time(),'scope':'only this owned disposable QEMU UUID'})+'\n');print('owned QEMU killed')
if __name__=='__main__':
    action=sys.argv[1]
    if action in ['setup','verify-reboot','verify-crash','cleanup']:phase(action)
    else:{'upload':upload,'pin':pin,'isolation':isolation,'crash':crash}[action]()
